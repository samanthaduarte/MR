﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Compcamara : MonoBehaviour {
	Vector3 camara;
	float vel;
	public int player;
	public Rigidbody rb;

	// Use this for initialization
	void Start () {
		camara = new Vector3(0.0f,0.0f,0.0f);
		vel = 10f;
	}
	
	// Update is called once per frame
	void Update () {
		camara.y = 0.0f;
		camara.x = 0.0f;
		camara.z = 0.0f;
		rb.freezeRotation = true;

        if (player == 1)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                camara.z = vel * Time.deltaTime;
                transform.Translate(camara);
            }
            if (Input.GetKey(KeyCode.DownArrow))
            {
                camara.z = -vel * Time.deltaTime;
                transform.Translate(camara);
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                camara.x = vel * Time.deltaTime;
                transform.Translate(camara);
            }
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                camara.x = -vel * Time.deltaTime;
                transform.Translate(camara);
            }
        }
        if (player == 2)
        {
            if (Input.GetKey(KeyCode.W))
            {
                camara.z = vel * Time.deltaTime;
                transform.Translate(camara);
            }
            if (Input.GetKey(KeyCode.S))
            {
                camara.z = -vel * Time.deltaTime;
                transform.Translate(camara);
            }
            if (Input.GetKey(KeyCode.D))
            {
                camara.x = vel * Time.deltaTime;
                transform.Translate(camara);
            }
            if (Input.GetKey(KeyCode.A))
            {
                camara.x = -vel * Time.deltaTime;
                transform.Translate(camara);
            }
        }
	}
}
