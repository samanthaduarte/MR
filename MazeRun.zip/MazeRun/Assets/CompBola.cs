﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompBola : MonoBehaviour {
	Vector3 bola;
	float vel;
	public int player;
	public Rigidbody rb;

	// Use this for initialization
	void Start () {
		bola = new Vector3(0.0f,0.0f,0.0f);
		vel = 10f;
	}
	
	// Update is called once per frame
	void Update () {
		bola.y = 0.0f;
		bola.x = 0.0f;
		bola.z = 0.0f;
		rb.freezeRotation = true;

		if (bola.y < 0){
			bola.y = 0.4f;
			bola.x = -7.5f;
			bola.z = -3.5f;
		}

        if (player == 1)
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                bola.z = vel * Time.deltaTime;
                transform.Translate(bola);
            }
            if (Input.GetKey(KeyCode.DownArrow))
            {
                bola.z = -vel * Time.deltaTime;
                transform.Translate(bola);
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                bola.x = vel * Time.deltaTime;
                transform.Translate(bola);
            }
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                bola.x = -vel * Time.deltaTime;
                transform.Translate(bola);
            }
        }
        if (player == 2)
        {
            if (Input.GetKey(KeyCode.W))
            {
                bola.z = vel * Time.deltaTime;
                transform.Translate(bola);
            }
            if (Input.GetKey(KeyCode.S))
            {
                bola.z = -vel * Time.deltaTime;
                transform.Translate(bola);
            }
            if (Input.GetKey(KeyCode.D))
            {
                bola.x = vel * Time.deltaTime;
                transform.Translate(bola);
            }
            if (Input.GetKey(KeyCode.A))
            {
                bola.x = -vel * Time.deltaTime;
                transform.Translate(bola);
            }
        }
	}
}
